package com.ecomarket.pedidos.models.entity;

public enum EstadoPedido {
    PENDIENTE,
    CONFIRMADA,
    ENVIADA,
    ENTREGADA,
    CANCELADA, PROCESANDO
}
