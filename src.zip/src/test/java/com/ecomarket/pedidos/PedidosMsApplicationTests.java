package com.ecomarket.pedidos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidosMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
